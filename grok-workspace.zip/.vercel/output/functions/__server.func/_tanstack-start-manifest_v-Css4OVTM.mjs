//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Css4OVTM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CMm13fUK.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CMm13fUK.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DK0vB-8t.js"]
	}
} });
//#endregion
export { tsrStartManifest };
