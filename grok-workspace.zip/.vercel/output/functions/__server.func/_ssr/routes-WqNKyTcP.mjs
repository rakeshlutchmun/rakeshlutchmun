import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Monitor, c as Check, i as PenTool, l as ArrowUpRight, o as Menu, r as Printer, s as Layers, t as X } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-WqNKyTcP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var disciplines = [
	"All",
	"Identity",
	"Digital",
	"Web",
	"Print"
];
var projects = [
	{
		id: "aurum",
		title: "Aurum",
		specimen: "Resort identity",
		year: "2025",
		discipline: "Identity",
		summary: "A mark cut from one arc. Quiet enough for a front desk, strict enough for a sign.",
		brief: "The brief arrived as a gold script and a brochure of sunsets. The place needed to feel expensive without looking like every other island hotel.",
		approach: "The script went. The mark is a single arc and a cut counter. Black, bone, and a measured cyan. Stationery and the site share one grid.",
		outcome: "A system the desk, the site, and the beach sign can all use without a seasonal redesign.",
		deliverables: [
			"Wordmark",
			"Monogram",
			"Colour rules",
			"Stationery",
			"Signage grid"
		]
	},
	{
		id: "isle",
		title: "Isle",
		specimen: "Harbour festival",
		year: "2025",
		discipline: "Digital",
		summary: "One bar, one slash, type you can read from a moving car.",
		brief: "A one-night harbour festival needed a poster that still worked as a story, a ticket, and a LED wall.",
		approach: "Nothing illustrative. A cyan column, an ember slash, and a name set so large the crop can change and the poster still holds.",
		outcome: "One master that scales from a phone story to a hoarding without a second layout.",
		deliverables: [
			"Poster system",
			"Story crops",
			"Ticket",
			"Motion stills"
		]
	},
	{
		id: "roast",
		title: "Roast 21",
		specimen: "Coffee packing",
		year: "2024",
		discipline: "Print",
		summary: "The red is rationed. One word is allowed to shout.",
		brief: "A small roaster wanted packaging that looked considered on a black shelf and readable in a morning kitchen.",
		approach: "A bone label, a cyan stamp, and the word ROAST in ember. Everything else is quiet type: origin, grind, a short rule.",
		outcome: "A pouch, a stamp, and a café menu that obviously belong together.",
		deliverables: [
			"Pouch",
			"Stamp",
			"Menu",
			"Shelf card"
		]
	},
	{
		id: "kite",
		title: "Kite",
		specimen: "Finance product",
		year: "2025",
		discipline: "Web",
		summary: "Cyan is the data. Ember is the only number that matters.",
		brief: "A finance app was loud: gradients, confetti, three accents. People could not find the balance.",
		approach: "Black screens. One chart language. The figure you came for is ember; everything else steps back. Type is the interface.",
		outcome: "A product UI a person can read at arm’s length on a bright pavement.",
		deliverables: [
			"App UI",
			"Chart system",
			"Type scale",
			"Marketing site"
		]
	},
	{
		id: "mare",
		title: "Mare",
		specimen: "Dining room",
		year: "2024",
		discipline: "Print",
		summary: "A tasting menu set like a score. Rules, not decoration.",
		brief: "The room was already dark. The menu was a script font on cream card, and it fought the food.",
		approach: "Courses numbered, a single cyan rule, ember only on the wine. Paper large enough to feel like an object.",
		outcome: "Print that sits on the table and does not ask to be photographed to be understood.",
		deliverables: [
			"Menu",
			"Wine card",
			"Reservation card",
			"Type specimen"
		]
	},
	{
		id: "form",
		title: "Form 09",
		specimen: "Exhibition site",
		year: "2026",
		discipline: "Digital",
		summary: "The grid is the exhibit. The site does not decorate the work.",
		brief: "A nine-artist show needed a site that could change order every week and still look authored.",
		approach: "Twelve columns, a circle that marks the current room, and type that can be swapped without breaking the poster.",
		outcome: "A site the gallery updates by changing words, not by calling the studio back.",
		deliverables: [
			"Exhibition site",
			"Room grid",
			"Poster",
			"Wayfinding"
		]
	}
];
var services = [
	{
		title: "Identity",
		text: "Marks, type, and colour rules a brand can keep using after the launch week."
	},
	{
		title: "Web",
		text: "Sites and product screens drawn at phone width first, then opened up."
	},
	{
		title: "Digital",
		text: "Posters, campaigns, and systems that crop cleanly from a story to a wall."
	},
	{
		title: "Print",
		text: "Packaging, menus, and signage with the same grid as the screen work."
	}
];
var steps = [
	{
		n: "01",
		title: "Listen",
		text: "The brief, the constraint, and the thing the brand refuses to say out loud."
	},
	{
		n: "02",
		title: "System",
		text: "Type, grid, two colours. Rules are written before anything is decorated."
	},
	{
		n: "03",
		title: "Make",
		text: "Marks, pages, and files a printer and a developer can both open."
	},
	{
		n: "04",
		title: "Hold",
		text: "Checked on a phone, a laptop, and a print sheet. Then it is handed over."
	}
];
var ticker = [
	"Identity",
	"Web",
	"Digital",
	"Print",
	"Type",
	"Grid",
	"Black field",
	"Mauritius"
];
var NOTES_KEY = "rl-studio-notes";
function Frame({ w = 400, h = 520, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "block h-full w-full",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: w,
			height: h,
			className: "fill-bg"
		}), children]
	});
}
function CropMarks({ w, h }) {
	const m = 16;
	const len = 18;
	const lines = [
		[
			m,
			m,
			34,
			m
		],
		[
			m,
			m,
			m,
			34
		],
		[
			w - m,
			m,
			w - m - len,
			m
		],
		[
			w - m,
			m,
			w - m,
			34
		],
		[
			m,
			h - m,
			34,
			h - m
		],
		[
			m,
			h - m,
			m,
			h - m - len
		],
		[
			w - m,
			h - m,
			w - m - len,
			h - m
		],
		[
			w - m,
			h - m,
			w - m,
			h - m - len
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
		className: "stroke-muted",
		strokeWidth: "1",
		fill: "none",
		children: lines.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: line[0],
			y1: line[1],
			x2: line[2],
			y2: line[3]
		}, i))
	});
}
function Mark({ className = "size-9" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `relative inline-flex items-center justify-center overflow-hidden bg-fg font-display text-sm font-extrabold tracking-tight text-bg ${className}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 left-0 top-0 w-1 bg-cyan" }),
			"RL",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-0.5 top-0.5 size-1.5 bg-ember" })
		]
	});
}
function Poster({ id }) {
	switch (id) {
		case "aurum": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aurum, {});
		case "isle": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Isle, {});
		case "roast": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roast, {});
		case "kite": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kite, {});
		case "mare": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mare, {});
		case "form": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormPoster, {});
		default: return null;
	}
}
function Aurum() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CropMarks, {
			w: 400,
			h: 520
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "248",
			cy: "196",
			r: "112",
			className: "fill-none stroke-cyan",
			strokeWidth: "1.5"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "248",
			cy: "196",
			r: "72",
			className: "fill-none stroke-line",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M248 84 A112 112 0 0 1 348 250",
			className: "fill-none stroke-ember",
			strokeWidth: "6"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "40",
			y: "40",
			width: "16",
			height: "16",
			className: "fill-ember"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "40",
			y: "430",
			className: "poster-type fill-fg",
			fontSize: "54",
			children: "AURUM"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "40",
			y: "462",
			className: "poster-meta fill-muted",
			fontSize: "12",
			children: "ONE ARC · IDENTITY"
		})
	] });
}
function Isle() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "0",
			y: "0",
			width: "22",
			height: "520",
			className: "fill-cyan"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "70",
			y1: "-20",
			x2: "430",
			y2: "470",
			className: "stroke-ember",
			strokeWidth: "10"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "48",
			y: "250",
			className: "poster-type fill-fg",
			fontSize: "92",
			children: "ISLE"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "52",
			y: "292",
			className: "poster-meta fill-fg",
			fontSize: "13",
			children: "HARBOUR / NIGHT"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "52",
			y: "470",
			className: "poster-meta fill-cyan",
			fontSize: "12",
			children: "21 JUNE"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "300",
			y: "470",
			className: "poster-type fill-ember",
			fontSize: "28",
			children: "25"
		})
	] });
}
function Roast() {
	const bars = Array.from({ length: 18 }, (_, i) => i);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "36",
			y: "36",
			width: "328",
			height: "448",
			className: "fill-none stroke-line",
			strokeWidth: "1"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "58",
			y: "78",
			width: "284",
			height: "340",
			className: "fill-surface"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "78",
			y: "108",
			width: "36",
			height: "36",
			className: "fill-cyan"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "78",
			y: "188",
			className: "poster-meta fill-muted",
			fontSize: "12",
			children: "ORIGIN"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "78",
			y: "250",
			className: "poster-type fill-fg",
			fontSize: "52",
			children: "ROAST"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "78",
			y: "330",
			className: "poster-type fill-ember",
			fontSize: "64",
			children: "21"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", { children: bars.map((bar) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: 78 + bar * 13,
			y: "390",
			width: bar % 4 === 0 ? 8 : 4,
			height: "22",
			className: bar % 5 === 0 ? "fill-cyan" : "fill-fg"
		}, bar)) })
	] });
}
function Kite() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "36",
			y: "64",
			className: "poster-type fill-fg",
			fontSize: "28",
			children: "KITE"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "250",
			y: "64",
			className: "poster-type fill-ember",
			fontSize: "28",
			children: "2.4"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "36",
			y: "96",
			width: "328",
			height: "300",
			className: "fill-surface"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "56",
			y1: "360",
			x2: "344",
			y2: "360",
			className: "stroke-line",
			strokeWidth: "1"
		}),
		[
			46,
			78,
			62,
			110,
			88,
			140,
			96,
			70,
			120,
			84
		].map((height, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: 60 + i * 30,
			y: 360 - height,
			width: "16",
			height,
			className: i === 5 ? "fill-ember" : "fill-cyan"
		}, i)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "36",
			y: "460",
			className: "poster-meta fill-muted",
			fontSize: "12",
			children: "CYAN IS DATA · EMBER IS THE FIGURE"
		})
	] });
}
function Mare() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "40",
			y: "78",
			className: "poster-type fill-fg",
			fontSize: "48",
			children: "MARE"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "230",
			y: "72",
			className: "poster-meta fill-ember",
			fontSize: "12",
			children: "TABLE"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "40",
			y: "100",
			width: "72",
			height: "4",
			className: "fill-cyan"
		}),
		[
			["01", "Oyster"],
			["02", "Line fish"],
			["03", "Citrus"],
			["04", "Dark rum"]
		].map(([n, name], i) => {
			const y = 180 + i * 68;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "40",
					y1: y - 36,
					x2: "360",
					y2: y - 36,
					className: "stroke-line",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "40",
					y,
					className: "poster-meta fill-cyan",
					fontSize: "13",
					children: n
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "100",
					y,
					className: "poster-type fill-fg",
					fontSize: "26",
					children: name
				})
			] }, n);
		})
	] });
}
function FormPoster() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "36",
			y: "58",
			className: "poster-meta fill-muted",
			fontSize: "12",
			children: "ROOM GRID"
		}),
		[
			[
				0,
				0,
				"fill-raised"
			],
			[
				1,
				0,
				"fill-raised"
			],
			[
				2,
				0,
				"fill-cyan"
			],
			[
				0,
				1,
				"fill-raised"
			],
			[
				3,
				1,
				"fill-fg"
			],
			[
				1,
				2,
				"fill-raised"
			],
			[
				2,
				2,
				"fill-ember"
			],
			[
				3,
				2,
				"fill-raised"
			],
			[
				0,
				3,
				"fill-fg"
			],
			[
				2,
				3,
				"fill-raised"
			]
		].map(([col, row, fill], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: 36 + col * 84,
			y: 84 + row * 72,
			width: "76",
			height: "64",
			className: fill
		}, i)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "318",
			cy: "250",
			r: "46",
			className: "fill-none stroke-ember",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "36",
			y: "450",
			className: "poster-type fill-fg",
			fontSize: "48",
			children: "FORM"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "250",
			y: "450",
			className: "poster-type fill-cyan",
			fontSize: "48",
			children: "09"
		})
	] });
}
function FieldGraphic({ mode, columns, shift, heat }) {
	const uid = (0, import_react.useId)().replace(/:/g, "");
	const w = 640;
	const h = 400;
	const ember = heat / 100;
	const gap = w / columns;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "block h-full w-full",
		role: "img",
		"aria-label": "Live construction graphic",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: w,
				height: h,
				className: "fill-bg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
				id: uid,
				width: gap,
				height: gap,
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: `M ${gap} 0 H 0 V ${gap}`,
					className: "stroke-line",
					strokeWidth: "1",
					fill: "none"
				})
			}) }),
			mode === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: w,
				height: h,
				fill: `url(#${uid})`
			}) : null,
			mode === "grid" ? Array.from({ length: columns }, (_, i) => (i + shift) % 3 === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: i * gap,
				y: "0",
				width: Math.max(gap - 8, 6),
				height: h,
				className: "fill-cyan",
				opacity: "0.18"
			}, i) : null) : null,
			mode === "poster" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 28 + shift * 10,
					y: "0",
					width: 8 + columns,
					height: h,
					className: "fill-cyan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: shift * 36,
					y1: "0",
					x2: w,
					y2: h - shift * 16,
					className: "stroke-ember",
					strokeWidth: "8",
					opacity: ember
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "48",
					y: "230",
					className: "poster-type fill-fg",
					fontSize: "140",
					children: "RL"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "52",
					y: "280",
					className: "poster-meta fill-muted",
					fontSize: "14",
					children: `FIELD / ${String(columns).padStart(2, "0")} COL`
				}),
				Array.from({ length: Math.min(columns, 12) }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 48 + i * 28,
					y: "320",
					width: "16",
					height: i === shift % columns ? 48 : 22 + i * 7 % 18,
					className: i === shift % columns ? "fill-ember" : "fill-fg",
					opacity: i === shift % columns ? ember : 1
				}, i))
			] }) : null,
			mode === "mark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: 320,
					cy: 190,
					r: 70 + columns * 6,
					className: "fill-none stroke-cyan",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 250 + shift * 6,
					y: "120",
					width: "120",
					height: "120",
					className: "fill-none stroke-fg",
					strokeWidth: "2",
					transform: `rotate(${shift * 6} 320 190)`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "300",
					y: "170",
					width: "28",
					height: "80",
					className: "fill-fg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "300",
					y: "170",
					width: "70",
					height: "16",
					className: "fill-fg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "300",
					y: "214",
					width: "52",
					height: "16",
					className: "fill-fg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "360",
					y: "250",
					width: "22",
					height: "22",
					className: "fill-ember",
					opacity: ember
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "48",
					y: "360",
					className: "poster-meta fill-muted",
					fontSize: "14",
					children: "MARK · CONSTRUCTED"
				})
			] }) : null,
			mode === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: shift * 28,
					y: 80 + columns % 5 * 16,
					width: "180",
					height: "8",
					className: "fill-ember",
					opacity: ember
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "36",
					y: "48",
					className: "poster-meta fill-fg",
					fontSize: "14",
					children: `GRID ${columns} · SHIFT ${shift}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "36",
					y: "360",
					className: "poster-type fill-fg",
					fontSize: "64",
					children: "FIELD"
				})
			] }) : null
		]
	});
}
var EMPTY = {
	name: "",
	email: "",
	kind: "Web",
	message: ""
};
var serviceIcons = [
	PenTool,
	Monitor,
	Layers,
	Printer
];
function scrollToId(id) {
	const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	document.getElementById(id)?.scrollIntoView({
		behavior: reduce ? "auto" : "smooth",
		block: "start"
	});
}
function readNotes() {
	try {
		const raw = localStorage.getItem(NOTES_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function writeNotes(notes) {
	localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
}
function Site() {
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(EMPTY);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [notes, setNotes] = (0, import_react.useState)([]);
	const [sent, setSent] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("poster");
	const [columns, setColumns] = (0, import_react.useState)(8);
	const [shift, setShift] = (0, import_react.useState)(3);
	const [heat, setHeat] = (0, import_react.useState)(42);
	const closeRef = (0, import_react.useRef)(null);
	const nameRef = (0, import_react.useRef)(null);
	const visible = filter === "All" ? projects : projects.filter((project) => project.discipline === filter);
	const active = projects.find((project) => project.id === activeId) ?? null;
	(0, import_react.useEffect)(() => {
		setNotes(readNotes());
	}, []);
	(0, import_react.useEffect)(() => {
		const locked = menu || activeId !== null;
		document.body.style.overflow = locked ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [menu, activeId]);
	(0, import_react.useEffect)(() => {
		if (!activeId && !menu) return;
		const onKey = (event) => {
			if (event.key === "Escape") {
				setActiveId(null);
				setMenu(false);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [activeId, menu]);
	(0, import_react.useEffect)(() => {
		if (activeId) closeRef.current?.focus();
	}, [activeId]);
	function adoptField() {
		const line = `Field study: ${mode}, ${columns} columns, shift ${shift}, heat ${heat}.`;
		setDraft((current) => ({
			...current,
			kind: "Digital",
			message: current.message.trim() ? `${current.message.trim()}\n${line}` : line
		}));
		setSent(null);
		scrollToId("contact");
	}
	function validate(next) {
		const found = {};
		if (next.name.trim().length < 2) found.name = "Add your name.";
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.email.trim())) found.email = "Use a real email address.";
		if (next.message.trim().length < 12) found.message = "Say a little more about the work — at least a sentence.";
		return found;
	}
	function submit(event) {
		event.preventDefault();
		const found = validate(draft);
		setErrors(found);
		if (Object.keys(found).length > 0) {
			if (found.name) nameRef.current?.focus();
			return;
		}
		const note = {
			...draft,
			name: draft.name.trim(),
			email: draft.email.trim(),
			message: draft.message.trim(),
			id: crypto.randomUUID(),
			at: (/* @__PURE__ */ new Date()).toISOString()
		};
		const next = [note, ...notes].slice(0, 8);
		setNotes(next);
		writeNotes(next);
		setSent(note);
		setDraft(EMPTY);
		setErrors({});
	}
	function removeNote(id) {
		const next = notes.filter((note) => note.id !== id);
		setNotes(next);
		writeNotes(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#work",
				className: "sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-cyan focus:px-4 focus:py-3 focus:text-bg",
				children: "Skip to work"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
				menu,
				onMenu: () => setMenu((open) => !open),
				onNavigate: () => setMenu(false)
			}),
			menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileNav, { onNavigate: () => setMenu(false) }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticker, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Work, {
					filter,
					visible,
					onFilter: setFilter,
					onOpen: setActiveId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					mode,
					columns,
					shift,
					heat,
					onMode: setMode,
					onColumns: setColumns,
					onShift: setShift,
					onHeat: setHeat,
					onAdopt: adoptField
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Practice, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {
					draft,
					errors,
					sent,
					notes,
					nameRef,
					onChange: (patch) => {
						setDraft((current) => ({
							...current,
							...patch
						}));
						setSent(null);
					},
					onSubmit: submit,
					onRemove: removeNote,
					onReset: () => setSent(null)
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Case, {
				project: active,
				visible,
				closeRef,
				onClose: () => setActiveId(null),
				onOpen: setActiveId
			}) : null
		]
	});
}
function Header({ menu, onMenu, onNavigate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-center gap-3",
					onClick: onNavigate,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-sm font-bold tracking-wide",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sm:hidden",
							children: "RL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "RAKESH LUTCHMUN"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-6 md:flex",
					"aria-label": "Primary",
					children: [[
						["work", "Work"],
						["field", "Field"],
						["practice", "Practice"],
						["contact", "Contact"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `#${id}`,
						className: "text-sm text-muted transition-colors duration-200 hover:text-fg",
						children: label
					}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#contact",
						className: "inline-flex h-11 items-center bg-cyan px-4 text-sm font-medium text-bg",
						children: "Start a project"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center border border-line md:hidden",
					"aria-expanded": menu,
					"aria-label": menu ? "Close menu" : "Open menu",
					onClick: onMenu,
					children: menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})
			]
		})
	});
}
function MobileNav({ onNavigate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-30 flex flex-col bg-bg px-5 pt-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex flex-col",
			"aria-label": "Mobile",
			children: [
				["work", "Work"],
				["field", "Field"],
				["practice", "Practice"],
				["contact", "Contact"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: `#${id}`,
				className: "border-b border-line py-4 font-display text-4xl font-bold",
				onClick: onNavigate,
				children: label
			}, id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#contact",
			onClick: onNavigate,
			className: "mt-8 inline-flex h-12 items-center justify-center bg-cyan text-sm font-medium text-bg",
			children: "Start a project"
		})]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": "true",
			className: "hero-grid pointer-events-none absolute inset-0 opacity-70"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto grid max-w-6xl items-end gap-10 px-5 py-14 sm:py-20 lg:grid-cols-12 lg:gap-8 lg:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-5 flex items-center gap-3 text-xs font-medium tracking-widest text-cyan uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative flex size-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inline-flex size-full animate-ping rounded-full bg-cyan opacity-60" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative size-2 rounded-full bg-cyan" })]
						}), "Open for commissions · Mauritius"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display text-6xl leading-none font-extrabold tracking-tight uppercase sm:text-7xl lg:text-8xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block",
							children: "Rakesh"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block",
							children: "Lutchmun"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-lg text-muted sm:text-xl",
						children: "Graphic designer and web designer. Identities, digital graphics, and sites composed on a black field — drawn to stay sharp on every screen."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#work",
							className: "inline-flex h-12 items-center justify-center gap-2 bg-cyan px-5 text-sm font-medium text-bg",
							children: ["See the work", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							className: "inline-flex h-12 items-center justify-center border border-line px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-cyan",
							children: "Start a project"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "lg:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							className: "absolute top-8 -left-0 h-3/5 w-1.5 bg-cyan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							className: "absolute -right-0 -bottom-3 h-1.5 w-24 bg-ember"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/rakesh.jpg",
							alt: "Rakesh Lutchmun in profile, lit by red and cyan studio light",
							width: 864,
							height: 867,
							className: "aspect-square w-full object-cover"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
					className: "mt-4 flex items-center justify-between text-xs tracking-widest text-muted uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Studio portrait" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Black · Cyan · Ember" })]
				})]
			})]
		})]
	});
}
function Ticker() {
	const row = [...ticker, ...ticker];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden border-y border-line",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ticker-track flex w-max",
			children: [0, 1].map((copy) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex",
				children: row.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-8 px-4 py-3 text-xs font-medium tracking-widest text-muted uppercase",
					children: [item, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 bg-cyan" })]
				}, `${copy}-${item}-${index}`))
			}, copy))
		})
	});
}
function Work({ filter, visible, onFilter, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "work",
		className: "scroll-mt-20 mx-auto max-w-6xl px-5 py-16 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-cyan uppercase",
					children: "Selected work"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl",
					children: "Studies in black"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-muted",
					children: "Six directions: identity, night posters, packing, product UI, menus, exhibition sites. The photograph is the only camera. The rest is drawn."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex gap-2 overflow-x-auto pb-1",
				role: "group",
				"aria-label": "Filter work",
				children: disciplines.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": filter === item,
					onClick: () => onFilter(item),
					className: clsx("h-11 shrink-0 border px-4 text-sm transition-colors duration-200", filter === item ? "border-cyan bg-cyan text-bg" : "border-line text-fg hover:border-fg"),
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs tracking-widest text-muted uppercase tabular-nums",
				children: [String(visible.length).padStart(2, "0"), " shown"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid grid-cols-1 gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3",
				children: visible.map((project, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(project.id),
					className: "group w-full text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "sr-only",
							children: [
								"Open ",
								project.title,
								" study"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative overflow-hidden border border-line bg-surface transition-colors duration-200 group-hover:border-cyan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "aspect-[4/5]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, { id: project.id })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-3 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl font-bold",
								children: project.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tracking-widest text-muted tabular-nums",
								children: String(index + 1).padStart(2, "0")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-sm text-muted",
							children: [
								project.discipline,
								" · ",
								project.year
							]
						})
					]
				}) }, project.id))
			})
		]
	});
}
function Field({ mode, columns, shift, heat, onMode, onColumns, onShift, onHeat, onAdopt }) {
	const labelId = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "field",
		className: "scroll-mt-20 border-t border-line bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:py-24 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-cyan uppercase",
						children: "Digital graphic"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: labelId,
						className: "mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl",
						children: "Move the system"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted",
						children: "The same rules, a different poster. Columns, shift, and how much ember is allowed. This is how a black-field identity starts — before a logo is precious."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						role: "group",
						"aria-labelledby": labelId,
						children: [
							"poster",
							"grid",
							"mark"
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": mode === item,
							onClick: () => onMode(item),
							className: clsx("h-11 border px-4 text-sm capitalize transition-colors duration-200", mode === item ? "border-fg bg-fg text-bg" : "border-line text-fg hover:border-fg"),
							children: item
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Range, {
								label: "Columns",
								value: columns,
								min: 4,
								max: 12,
								onChange: onColumns
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Range, {
								label: "Shift",
								value: shift,
								min: 0,
								max: 8,
								onChange: onShift
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Range, {
								label: "Heat",
								value: heat,
								min: 0,
								max: 100,
								onChange: onHeat
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs tracking-widest text-muted uppercase tabular-nums",
						children: [
							mode,
							" · ",
							columns,
							" col · shift ",
							shift,
							" · heat ",
							heat
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onAdopt,
						className: "mt-6 inline-flex h-12 items-center gap-2 border border-cyan px-5 text-sm font-medium text-cyan transition-colors duration-200 hover:bg-cyan hover:text-bg",
						children: ["Use this direction", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border border-line bg-bg lg:col-span-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-[16/10]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldGraphic, {
						mode,
						columns,
						shift,
						heat
					})
				})
			})]
		})
	});
}
function Range({ label, value, min, max, onChange }) {
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		htmlFor: id,
		className: "block py-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center justify-between text-xs tracking-widest text-muted uppercase",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-fg tabular-nums",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			className: "studio-range",
			type: "range",
			min,
			max,
			value,
			onChange: (event) => onChange(Number(event.target.value))
		})]
	});
}
function Practice() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "practice",
		className: "scroll-mt-20 mx-auto max-w-6xl px-5 py-16 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-cyan uppercase",
				children: "Practice"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 max-w-3xl font-display text-4xl font-bold tracking-tight sm:text-5xl",
				children: "Two inks. A grid. Then the job."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 grid gap-4 sm:grid-cols-2",
				children: services.map((service, index) => {
					const Icon = serviceIcons[index];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line bg-surface p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5 text-cyan",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-2xl font-bold",
								children: service.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: service.text
							})
						]
					}, service.title);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-12 grid gap-8 border-t border-line pt-10 sm:grid-cols-2 lg:grid-cols-4",
				children: steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-sm font-bold text-ember tabular-nums",
						children: step.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 font-display text-2xl font-bold",
						children: step.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: step.text
					})
				] }, step.n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 grid gap-8 border border-line bg-surface p-6 sm:p-10 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-3xl font-bold",
							children: "About the studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: "Rakesh Lutchmun designs identities and websites for people who want to be recognised before they are explained. The work is built on black — proportion first, then type, then two colours that do the pointing. Based in Mauritius. Commissioned from anywhere the brief is serious."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted",
							children: "You work with him directly. No account layer between the drawing and the decision."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "grid grid-cols-2 gap-3 lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
							name: "Field",
							className: "bg-bg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
							name: "Bone",
							className: "bg-fg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
							name: "Signal",
							className: "bg-cyan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
							name: "Emphasis",
							className: "bg-ember"
						})
					]
				})]
			})
		]
	});
}
function Swatch({ name, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "border border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-16 ${className}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-3 py-2 text-xs tracking-widest text-muted uppercase",
			children: name
		})]
	});
}
function Contact({ draft, errors, sent, notes, nameRef, onChange, onSubmit, onRemove, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "scroll-mt-20 border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:py-24 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-cyan uppercase",
						children: "Contact"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl",
						children: "Start a project"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted",
						children: "Tell the studio what needs to exist. Notes stay on this device so you can come back to them — nothing is sent to a server."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-sm text-muted",
						children: ["Studio", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-fg",
							children: "studio@rakeshlutchmun.design"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-muted",
						children: ["Based in", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-fg",
							children: "Mauritius"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border border-cyan bg-surface p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-6 text-cyan",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "mt-4 font-display text-3xl font-bold",
							children: [
								"Noted, ",
								sent.name,
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-muted",
							children: [
								"Your ",
								sent.kind.toLowerCase(),
								" note is saved in this browser. Reopen the studio on this device and it will still be here."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onReset,
							className: "mt-6 inline-flex h-12 items-center border border-line px-5 text-sm font-medium",
							children: "Write another"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					noValidate: true,
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							label: "Name",
							error: errors.name,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: nameRef,
								value: draft.name,
								onChange: (event) => onChange({ name: event.target.value }),
								autoComplete: "name",
								"aria-invalid": Boolean(errors.name),
								className: "h-12 w-full border border-line bg-surface px-3 text-fg outline-none placeholder:text-muted focus:border-cyan",
								placeholder: "Your name"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							label: "Email",
							error: errors.email,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.email,
								onChange: (event) => onChange({ email: event.target.value }),
								autoComplete: "email",
								inputMode: "email",
								"aria-invalid": Boolean(errors.email),
								className: "h-12 w-full border border-line bg-surface px-3 text-fg outline-none placeholder:text-muted focus:border-cyan",
								placeholder: "you@studio.com"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							label: "Kind of work",
							error: errors.kind,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: draft.kind,
								onChange: (event) => onChange({ kind: event.target.value }),
								className: "h-12 w-full border border-line bg-surface px-3 text-fg outline-none focus:border-cyan",
								children: [
									"Identity",
									"Web",
									"Digital",
									"Print",
									"Not sure"
								].map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: kind,
									children: kind
								}, kind))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							label: "The brief",
							error: errors.message,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: draft.message,
								onChange: (event) => onChange({ message: event.target.value }),
								"aria-invalid": Boolean(errors.message),
								rows: 5,
								className: "w-full resize-y border border-line bg-surface px-3 py-3 text-fg outline-none placeholder:text-muted focus:border-cyan",
								placeholder: "What should people recognise before you explain it?"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "inline-flex h-12 items-center justify-center bg-ember px-5 text-sm font-medium text-bg",
							children: "Save the note"
						})
					]
				}), notes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 divide-y divide-line border-t border-line",
					children: notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-medium",
							children: [
								note.name,
								" · ",
								note.kind
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: note.message
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onRemove(note.id),
							className: "h-11 shrink-0 px-2 text-xs tracking-widest text-muted uppercase",
							children: "Remove"
						})]
					}, note.id))
				}) : null]
			})]
		})
	});
}
function FieldLabel({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-2 block text-xs tracking-widest text-muted uppercase",
				children: label
			}),
			children,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-ember",
				children: error
			}) : null
		]
	});
}
function Case({ project, visible, closeRef, onClose, onOpen }) {
	const index = visible.findIndex((item) => item.id === project.id);
	const count = visible.length;
	const prev = visible[(index - 1 + count) % count];
	const next = visible[(index + 1) % count];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 overflow-y-auto bg-bg",
		role: "dialog",
		"aria-modal": "true",
		"aria-labelledby": "case-title",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-full max-w-6xl flex-col px-5 py-5 safe-bottom",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tracking-widest text-muted uppercase tabular-nums",
					children: [
						String(index + 1).padStart(2, "0"),
						" / ",
						String(count).padStart(2, "0")
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					ref: closeRef,
					type: "button",
					onClick: onClose,
					className: "inline-flex size-11 items-center justify-center border border-line",
					"aria-label": "Close study",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid items-start gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-[4/5]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, { id: project.id })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs tracking-widest text-cyan uppercase",
						children: [
							project.discipline,
							" · ",
							project.year
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "case-title",
						className: "mt-2 font-display text-5xl font-bold tracking-tight",
						children: project.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: project.specimen
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-lg",
						children: project.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 grid gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Brief"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: project.brief
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Approach"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: project.approach
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Outcome"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-fg",
								children: project.outcome
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 flex flex-wrap gap-2",
						children: project.deliverables.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border border-line px-3 py-2 text-xs tracking-widest text-muted uppercase",
							children: item
						}, item))
					}),
					count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onOpen(prev.id),
							className: "inline-flex h-12 flex-1 items-center justify-center border border-line text-sm",
							children: "Previous"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onOpen(next.id),
							className: "inline-flex h-12 flex-1 items-center justify-center bg-fg text-sm font-medium text-bg",
							children: "Next"
						})]
					}) : null
				] })]
			})]
		})
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-line safe-bottom",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-4 px-5 py-8 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-8 text-xs" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["Rakesh Lutchmun", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs tracking-widest uppercase",
						children: "Graphic & web design"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#top",
				className: "inline-flex h-11 items-center text-sm text-muted hover:text-fg",
				children: "Back to top"
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Site, {});
}
//#endregion
export { Home as component };
