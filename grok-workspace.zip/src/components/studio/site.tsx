import { useEffect, useId, useRef, useState, type FormEvent, type ReactNode, type RefObject } from "react";
import {
  ArrowUpRight,
  Check,
  Layers,
  Menu,
  Monitor,
  PenTool,
  Printer,
  X,
} from "lucide-react";
import { clsx } from "clsx";
import {
  NOTES_KEY,
  disciplines,
  projects,
  services,
  steps,
  ticker,
  type Discipline,
  type Filter,
  type Project,
} from "@/data/studio";
import { FieldGraphic, Mark, Poster, type FieldMode } from "@/components/studio/graphics";

type Draft = {
  name: string;
  email: string;
  kind: Discipline | "Not sure";
  message: string;
};

type Note = Draft & { id: string; at: string };

type Errors = Partial<Record<keyof Draft, string>>;

const EMPTY: Draft = {
  name: "",
  email: "",
  kind: "Web",
  message: "",
};

const serviceIcons = [PenTool, Monitor, Layers, Printer] as const;

function scrollToId(id: string) {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.getElementById(id)?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
}

function readNotes(): Note[] {
  try {
    const raw = localStorage.getItem(NOTES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Note[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeNotes(notes: Note[]) {
  localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
}

export function Site() {
  const [filter, setFilter] = useState<Filter>("All");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [notes, setNotes] = useState<Note[]>([]);
  const [sent, setSent] = useState<Note | null>(null);
  const [mode, setMode] = useState<FieldMode>("poster");
  const [columns, setColumns] = useState(8);
  const [shift, setShift] = useState(3);
  const [heat, setHeat] = useState(42);
  const closeRef = useRef<HTMLButtonElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);

  const visible = filter === "All" ? projects : projects.filter((project) => project.discipline === filter);
  const active = projects.find((project) => project.id === activeId) ?? null;

  useEffect(() => {
    setNotes(readNotes());
  }, []);

  useEffect(() => {
    const locked = menu || activeId !== null;
    document.body.style.overflow = locked ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menu, activeId]);

  useEffect(() => {
    if (!activeId && !menu) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setActiveId(null);
        setMenu(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeId, menu]);

  useEffect(() => {
    if (activeId) closeRef.current?.focus();
  }, [activeId]);

  function adoptField() {
    const line = `Field study: ${mode}, ${columns} columns, shift ${shift}, heat ${heat}.`;
    setDraft((current) => ({
      ...current,
      kind: "Digital",
      message: current.message.trim() ? `${current.message.trim()}\n${line}` : line,
    }));
    setSent(null);
    scrollToId("contact");
  }

  function validate(next: Draft): Errors {
    const found: Errors = {};
    if (next.name.trim().length < 2) found.name = "Add your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.email.trim())) found.email = "Use a real email address.";
    if (next.message.trim().length < 12) found.message = "Say a little more about the work — at least a sentence.";
    return found;
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    const found = validate(draft);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      if (found.name) nameRef.current?.focus();
      return;
    }
    const note: Note = {
      ...draft,
      name: draft.name.trim(),
      email: draft.email.trim(),
      message: draft.message.trim(),
      id: crypto.randomUUID(),
      at: new Date().toISOString(),
    };
    const next = [note, ...notes].slice(0, 8);
    setNotes(next);
    writeNotes(next);
    setSent(note);
    setDraft(EMPTY);
    setErrors({});
  }

  function removeNote(id: string) {
    const next = notes.filter((note) => note.id !== id);
    setNotes(next);
    writeNotes(next);
  }

  return (
    <div id="top" className="bg-bg text-fg">
      <a
        href="#work"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-cyan focus:px-4 focus:py-3 focus:text-bg"
      >
        Skip to work
      </a>
      <Header menu={menu} onMenu={() => setMenu((open) => !open)} onNavigate={() => setMenu(false)} />
      {menu ? <MobileNav onNavigate={() => setMenu(false)} /> : null}
      <main>
        <Hero />
        <Ticker />
        <Work filter={filter} visible={visible} onFilter={setFilter} onOpen={setActiveId} />
        <Field
          mode={mode}
          columns={columns}
          shift={shift}
          heat={heat}
          onMode={setMode}
          onColumns={setColumns}
          onShift={setShift}
          onHeat={setHeat}
          onAdopt={adoptField}
        />
        <Practice />
        <Contact
          draft={draft}
          errors={errors}
          sent={sent}
          notes={notes}
          nameRef={nameRef}
          onChange={(patch) => {
            setDraft((current) => ({ ...current, ...patch }));
            setSent(null);
          }}
          onSubmit={submit}
          onRemove={removeNote}
          onReset={() => setSent(null)}
        />
      </main>
      <Footer />
      {active ? (
        <Case
          project={active}
          visible={visible}
          closeRef={closeRef}
          onClose={() => setActiveId(null)}
          onOpen={setActiveId}
        />
      ) : null}
    </div>
  );
}

function Header({
  menu,
  onMenu,
  onNavigate,
}: {
  menu: boolean;
  onMenu: () => void;
  onNavigate: () => void;
}) {
  const links = [
    ["work", "Work"],
    ["field", "Field"],
    ["practice", "Practice"],
    ["contact", "Contact"],
  ] as const;

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5">
        <a href="#top" className="flex items-center gap-3" onClick={onNavigate}>
          <Mark />
          <span className="font-display text-sm font-bold tracking-wide">
            <span className="sm:hidden">RL</span>
            <span className="hidden sm:inline">RAKESH LUTCHMUN</span>
          </span>
        </a>
        <nav className="hidden items-center gap-6 md:flex" aria-label="Primary">
          {links.map(([id, label]) => (
            <a key={id} href={`#${id}`} className="text-sm text-muted transition-colors duration-200 hover:text-fg">
              {label}
            </a>
          ))}
          <a
            href="#contact"
            className="inline-flex h-11 items-center bg-cyan px-4 text-sm font-medium text-bg"
          >
            Start a project
          </a>
        </nav>
        <button
          type="button"
          className="inline-flex size-11 items-center justify-center border border-line md:hidden"
          aria-expanded={menu}
          aria-label={menu ? "Close menu" : "Open menu"}
          onClick={onMenu}
        >
          {menu ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
    </header>
  );
}

function MobileNav({ onNavigate }: { onNavigate: () => void }) {
  const links = [
    ["work", "Work"],
    ["field", "Field"],
    ["practice", "Practice"],
    ["contact", "Contact"],
  ] as const;
  return (
    <div className="fixed inset-0 z-30 flex flex-col bg-bg px-5 pt-20">
      <nav className="flex flex-col" aria-label="Mobile">
        {links.map(([id, label]) => (
          <a
            key={id}
            href={`#${id}`}
            className="border-b border-line py-4 font-display text-4xl font-bold"
            onClick={onNavigate}
          >
            {label}
          </a>
        ))}
      </nav>
      <a
        href="#contact"
        onClick={onNavigate}
        className="mt-8 inline-flex h-12 items-center justify-center bg-cyan text-sm font-medium text-bg"
      >
        Start a project
      </a>
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div aria-hidden="true" className="hero-grid pointer-events-none absolute inset-0 opacity-70" />
      <div className="relative mx-auto grid max-w-6xl items-end gap-10 px-5 py-14 sm:py-20 lg:grid-cols-12 lg:gap-8 lg:py-24">
        <div className="lg:col-span-7">
          <p className="mb-5 flex items-center gap-3 text-xs font-medium tracking-widest text-cyan uppercase">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-cyan opacity-60" />
              <span className="relative size-2 rounded-full bg-cyan" />
            </span>
            Open for commissions · Mauritius
          </p>
          <h1 className="font-display text-6xl leading-none font-extrabold tracking-tight uppercase sm:text-7xl lg:text-8xl">
            <span className="block">Rakesh</span>
            <span className="block">Lutchmun</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted sm:text-xl">
            Graphic designer and web designer. Identities, digital graphics, and sites composed on a black
            field — drawn to stay sharp on every screen.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href="#work"
              className="inline-flex h-12 items-center justify-center gap-2 bg-cyan px-5 text-sm font-medium text-bg"
            >
              See the work
              <ArrowUpRight className="size-4" />
            </a>
            <a
              href="#contact"
              className="inline-flex h-12 items-center justify-center border border-line px-5 text-sm font-medium text-fg transition-colors duration-200 hover:border-cyan"
            >
              Start a project
            </a>
          </div>
        </div>
        <figure className="lg:col-span-5">
          <div className="relative">
            <span aria-hidden="true" className="absolute top-8 -left-0 h-3/5 w-1.5 bg-cyan" />
            <span aria-hidden="true" className="absolute -right-0 -bottom-3 h-1.5 w-24 bg-ember" />
            <img
              src="/rakesh.jpg"
              alt="Rakesh Lutchmun in profile, lit by red and cyan studio light"
              width={864}
              height={867}
              className="aspect-square w-full object-cover"
            />
          </div>
          <figcaption className="mt-4 flex items-center justify-between text-xs tracking-widest text-muted uppercase">
            <span>Studio portrait</span>
            <span>Black · Cyan · Ember</span>
          </figcaption>
        </figure>
      </div>
    </section>
  );
}

function Ticker() {
  const row = [...ticker, ...ticker];
  return (
    <div className="overflow-hidden border-y border-line" aria-hidden="true">
      <div className="ticker-track flex w-max">
        {[0, 1].map((copy) => (
          <div key={copy} className="flex">
            {row.map((item, index) => (
              <span
                key={`${copy}-${item}-${index}`}
                className="flex items-center gap-8 px-4 py-3 text-xs font-medium tracking-widest text-muted uppercase"
              >
                {item}
                <span className="size-1.5 bg-cyan" />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

function Work({
  filter,
  visible,
  onFilter,
  onOpen,
}: {
  filter: Filter;
  visible: Project[];
  onFilter: (filter: Filter) => void;
  onOpen: (id: string) => void;
}) {
  return (
    <section id="work" className="scroll-mt-20 mx-auto max-w-6xl px-5 py-16 sm:py-24">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium tracking-widest text-cyan uppercase">Selected work</p>
          <h2 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">Studies in black</h2>
        </div>
        <p className="max-w-sm text-sm text-muted">
          Six directions: identity, night posters, packing, product UI, menus, exhibition sites. The photograph
          is the only camera. The rest is drawn.
        </p>
      </div>
      <div className="mt-8 flex gap-2 overflow-x-auto pb-1" role="group" aria-label="Filter work">
        {disciplines.map((item) => (
          <button
            key={item}
            type="button"
            aria-pressed={filter === item}
            onClick={() => onFilter(item)}
            className={clsx(
              "h-11 shrink-0 border px-4 text-sm transition-colors duration-200",
              filter === item ? "border-cyan bg-cyan text-bg" : "border-line text-fg hover:border-fg",
            )}
          >
            {item}
          </button>
        ))}
      </div>
      <p className="mt-4 text-xs tracking-widest text-muted uppercase tabular-nums">
        {String(visible.length).padStart(2, "0")} shown
      </p>
      <ul className="mt-6 grid grid-cols-1 gap-x-5 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((project, index) => (
          <li key={project.id}>
            <button
              type="button"
              onClick={() => onOpen(project.id)}
              className="group w-full text-left"
            >
              <span className="sr-only">Open {project.title} study</span>
              <div className="relative overflow-hidden border border-line bg-surface transition-colors duration-200 group-hover:border-cyan">
                <div className="aspect-[4/5]">
                  <Poster id={project.id} />
                </div>
              </div>
              <span className="mt-3 flex items-baseline justify-between gap-3">
                <span className="font-display text-xl font-bold">{project.title}</span>
                <span className="text-xs tracking-widest text-muted tabular-nums">
                  {String(index + 1).padStart(2, "0")}
                </span>
              </span>
              <span className="mt-1 block text-sm text-muted">
                {project.discipline} · {project.year}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Field({
  mode,
  columns,
  shift,
  heat,
  onMode,
  onColumns,
  onShift,
  onHeat,
  onAdopt,
}: {
  mode: FieldMode;
  columns: number;
  shift: number;
  heat: number;
  onMode: (mode: FieldMode) => void;
  onColumns: (value: number) => void;
  onShift: (value: number) => void;
  onHeat: (value: number) => void;
  onAdopt: () => void;
}) {
  const labelId = useId();
  const modes: FieldMode[] = ["poster", "grid", "mark"];
  return (
    <section id="field" className="scroll-mt-20 border-t border-line bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:py-24 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="text-xs font-medium tracking-widest text-cyan uppercase">Digital graphic</p>
          <h2 id={labelId} className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Move the system
          </h2>
          <p className="mt-4 text-muted">
            The same rules, a different poster. Columns, shift, and how much ember is allowed. This is how a
            black-field identity starts — before a logo is precious.
          </p>
          <div className="mt-6 flex flex-wrap gap-2" role="group" aria-labelledby={labelId}>
            {modes.map((item) => (
              <button
                key={item}
                type="button"
                aria-pressed={mode === item}
                onClick={() => onMode(item)}
                className={clsx(
                  "h-11 border px-4 text-sm capitalize transition-colors duration-200",
                  mode === item ? "border-fg bg-fg text-bg" : "border-line text-fg hover:border-fg",
                )}
              >
                {item}
              </button>
            ))}
          </div>
          <div className="mt-4">
            <Range label="Columns" value={columns} min={4} max={12} onChange={onColumns} />
            <Range label="Shift" value={shift} min={0} max={8} onChange={onShift} />
            <Range label="Heat" value={heat} min={0} max={100} onChange={onHeat} />
          </div>
          <p className="mt-2 text-xs tracking-widest text-muted uppercase tabular-nums">
            {mode} · {columns} col · shift {shift} · heat {heat}
          </p>
          <button
            type="button"
            onClick={onAdopt}
            className="mt-6 inline-flex h-12 items-center gap-2 border border-cyan px-5 text-sm font-medium text-cyan transition-colors duration-200 hover:bg-cyan hover:text-bg"
          >
            Use this direction
            <ArrowUpRight className="size-4" />
          </button>
        </div>
        <div className="border border-line bg-bg lg:col-span-7">
          <div className="aspect-[16/10]">
            <FieldGraphic mode={mode} columns={columns} shift={shift} heat={heat} />
          </div>
        </div>
      </div>
    </section>
  );
}

function Range({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
}) {
  const id = useId();
  return (
    <label htmlFor={id} className="block py-1">
      <span className="flex items-center justify-between text-xs tracking-widest text-muted uppercase">
        <span>{label}</span>
        <span className="text-fg tabular-nums">{value}</span>
      </span>
      <input
        id={id}
        className="studio-range"
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function Practice() {
  return (
    <section id="practice" className="scroll-mt-20 mx-auto max-w-6xl px-5 py-16 sm:py-24">
      <p className="text-xs font-medium tracking-widest text-cyan uppercase">Practice</p>
      <h2 className="mt-2 max-w-3xl font-display text-4xl font-bold tracking-tight sm:text-5xl">
        Two inks. A grid. Then the job.
      </h2>
      <ul className="mt-10 grid gap-4 sm:grid-cols-2">
        {services.map((service, index) => {
          const Icon = serviceIcons[index];
          return (
            <li key={service.title} className="border border-line bg-surface p-6">
              <Icon className="size-5 text-cyan" aria-hidden="true" />
              <h3 className="mt-5 font-display text-2xl font-bold">{service.title}</h3>
              <p className="mt-2 text-muted">{service.text}</p>
            </li>
          );
        })}
      </ul>
      <ol className="mt-12 grid gap-8 border-t border-line pt-10 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step) => (
          <li key={step.n}>
            <p className="font-display text-sm font-bold text-ember tabular-nums">{step.n}</p>
            <h3 className="mt-2 font-display text-2xl font-bold">{step.title}</h3>
            <p className="mt-2 text-sm text-muted">{step.text}</p>
          </li>
        ))}
      </ol>
      <div className="mt-14 grid gap-8 border border-line bg-surface p-6 sm:p-10 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <h3 className="font-display text-3xl font-bold">About the studio</h3>
          <p className="mt-4 text-muted">
            Rakesh Lutchmun designs identities and websites for people who want to be recognised before they
            are explained. The work is built on black — proportion first, then type, then two colours that do
            the pointing. Based in Mauritius. Commissioned from anywhere the brief is serious.
          </p>
          <p className="mt-4 text-muted">
            You work with him directly. No account layer between the drawing and the decision.
          </p>
        </div>
        <ul className="grid grid-cols-2 gap-3 lg:col-span-5">
          <Swatch name="Field" className="bg-bg" />
          <Swatch name="Bone" className="bg-fg" />
          <Swatch name="Signal" className="bg-cyan" />
          <Swatch name="Emphasis" className="bg-ember" />
        </ul>
      </div>
    </section>
  );
}

function Swatch({ name, className }: { name: string; className: string }) {
  return (
    <li className="border border-line">
      <div className={`h-16 ${className}`} />
      <p className="px-3 py-2 text-xs tracking-widest text-muted uppercase">{name}</p>
    </li>
  );
}

function Contact({
  draft,
  errors,
  sent,
  notes,
  nameRef,
  onChange,
  onSubmit,
  onRemove,
  onReset,
}: {
  draft: Draft;
  errors: Errors;
  sent: Note | null;
  notes: Note[];
  nameRef: RefObject<HTMLInputElement | null>;
  onChange: (patch: Partial<Draft>) => void;
  onSubmit: (event: FormEvent) => void;
  onRemove: (id: string) => void;
  onReset: () => void;
}) {
  const kinds: Draft["kind"][] = ["Identity", "Web", "Digital", "Print", "Not sure"];
  return (
    <section id="contact" className="scroll-mt-20 border-t border-line">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:py-24 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="text-xs font-medium tracking-widest text-cyan uppercase">Contact</p>
          <h2 className="mt-2 font-display text-4xl font-bold tracking-tight sm:text-5xl">Start a project</h2>
          <p className="mt-4 text-muted">
            Tell the studio what needs to exist. Notes stay on this device so you can come back to them — nothing
            is sent to a server.
          </p>
          <p className="mt-6 text-sm text-muted">
            Studio
            <span className="mt-1 block text-fg">studio@rakeshlutchmun.design</span>
          </p>
          <p className="mt-4 text-sm text-muted">
            Based in
            <span className="mt-1 block text-fg">Mauritius</span>
          </p>
        </div>
        <div className="lg:col-span-7">
          {sent ? (
            <div className="border border-cyan bg-surface p-6 sm:p-8">
              <Check className="size-6 text-cyan" aria-hidden="true" />
              <h3 className="mt-4 font-display text-3xl font-bold">Noted, {sent.name}.</h3>
              <p className="mt-3 text-muted">
                Your {sent.kind.toLowerCase()} note is saved in this browser. Reopen the studio on this device and
                it will still be here.
              </p>
              <button
                type="button"
                onClick={onReset}
                className="mt-6 inline-flex h-12 items-center border border-line px-5 text-sm font-medium"
              >
                Write another
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="grid gap-4">
              <FieldLabel label="Name" error={errors.name}>
                <input
                  ref={nameRef}
                  value={draft.name}
                  onChange={(event) => onChange({ name: event.target.value })}
                  autoComplete="name"
                  aria-invalid={Boolean(errors.name)}
                  className="h-12 w-full border border-line bg-surface px-3 text-fg outline-none placeholder:text-muted focus:border-cyan"
                  placeholder="Your name"
                />
              </FieldLabel>
              <FieldLabel label="Email" error={errors.email}>
                <input
                  value={draft.email}
                  onChange={(event) => onChange({ email: event.target.value })}
                  autoComplete="email"
                  inputMode="email"
                  aria-invalid={Boolean(errors.email)}
                  className="h-12 w-full border border-line bg-surface px-3 text-fg outline-none placeholder:text-muted focus:border-cyan"
                  placeholder="you@studio.com"
                />
              </FieldLabel>
              <FieldLabel label="Kind of work" error={errors.kind}>
                <select
                  value={draft.kind}
                  onChange={(event) => onChange({ kind: event.target.value as Draft["kind"] })}
                  className="h-12 w-full border border-line bg-surface px-3 text-fg outline-none focus:border-cyan"
                >
                  {kinds.map((kind) => (
                    <option key={kind} value={kind}>
                      {kind}
                    </option>
                  ))}
                </select>
              </FieldLabel>
              <FieldLabel label="The brief" error={errors.message}>
                <textarea
                  value={draft.message}
                  onChange={(event) => onChange({ message: event.target.value })}
                  aria-invalid={Boolean(errors.message)}
                  rows={5}
                  className="w-full resize-y border border-line bg-surface px-3 py-3 text-fg outline-none placeholder:text-muted focus:border-cyan"
                  placeholder="What should people recognise before you explain it?"
                />
              </FieldLabel>
              <button
                type="submit"
                className="inline-flex h-12 items-center justify-center bg-ember px-5 text-sm font-medium text-bg"
              >
                Save the note
              </button>
            </form>
          )}
          {notes.length > 0 ? (
            <ul className="mt-8 divide-y divide-line border-t border-line">
              {notes.map((note) => (
                <li key={note.id} className="flex items-start justify-between gap-4 py-4">
                  <div>
                    <p className="text-sm font-medium">
                      {note.name} · {note.kind}
                    </p>
                    <p className="mt-1 text-sm text-muted">{note.message}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemove(note.id)}
                    className="h-11 shrink-0 px-2 text-xs tracking-widest text-muted uppercase"
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      </div>
    </section>
  );
}

function FieldLabel({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs tracking-widest text-muted uppercase">{label}</span>
      {children}
      {error ? <span className="mt-1 block text-sm text-ember">{error}</span> : null}
    </label>
  );
}

function Case({
  project,
  visible,
  closeRef,
  onClose,
  onOpen,
}: {
  project: Project;
  visible: Project[];
  closeRef: RefObject<HTMLButtonElement | null>;
  onClose: () => void;
  onOpen: (id: string) => void;
}) {
  const index = visible.findIndex((item) => item.id === project.id);
  const count = visible.length;
  const prev = visible[(index - 1 + count) % count];
  const next = visible[(index + 1) % count];
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-bg" role="dialog" aria-modal="true" aria-labelledby="case-title">
      <div className="mx-auto flex min-h-full max-w-6xl flex-col px-5 py-5 safe-bottom">
        <div className="flex items-center justify-between">
          <p className="text-xs tracking-widest text-muted uppercase tabular-nums">
            {String(index + 1).padStart(2, "0")} / {String(count).padStart(2, "0")}
          </p>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            className="inline-flex size-11 items-center justify-center border border-line"
            aria-label="Close study"
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="mt-4 grid items-start gap-8 lg:grid-cols-2">
          <div className="border border-line">
            <div className="aspect-[4/5]">
              <Poster id={project.id} />
            </div>
          </div>
          <div>
            <p className="text-xs tracking-widest text-cyan uppercase">
              {project.discipline} · {project.year}
            </p>
            <h2 id="case-title" className="mt-2 font-display text-5xl font-bold tracking-tight">
              {project.title}
            </h2>
            <p className="mt-2 text-muted">{project.specimen}</p>
            <p className="mt-6 text-lg">{project.summary}</p>
            <dl className="mt-8 grid gap-5">
              <div>
                <dt className="text-xs tracking-widest text-muted uppercase">Brief</dt>
                <dd className="mt-1 text-sm text-fg">{project.brief}</dd>
              </div>
              <div>
                <dt className="text-xs tracking-widest text-muted uppercase">Approach</dt>
                <dd className="mt-1 text-sm text-fg">{project.approach}</dd>
              </div>
              <div>
                <dt className="text-xs tracking-widest text-muted uppercase">Outcome</dt>
                <dd className="mt-1 text-sm text-fg">{project.outcome}</dd>
              </div>
            </dl>
            <ul className="mt-6 flex flex-wrap gap-2">
              {project.deliverables.map((item) => (
                <li key={item} className="border border-line px-3 py-2 text-xs tracking-widest text-muted uppercase">
                  {item}
                </li>
              ))}
            </ul>
            {count > 1 ? (
              <div className="mt-8 flex gap-3">
                <button
                  type="button"
                  onClick={() => onOpen(prev.id)}
                  className="inline-flex h-12 flex-1 items-center justify-center border border-line text-sm"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => onOpen(next.id)}
                  className="inline-flex h-12 flex-1 items-center justify-center bg-fg text-sm font-medium text-bg"
                >
                  Next
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="border-t border-line safe-bottom">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-8 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Mark className="size-8 text-xs" />
          <p className="text-sm text-muted">
            Rakesh Lutchmun
            <span className="block text-xs tracking-widest uppercase">Graphic & web design</span>
          </p>
        </div>
        <a href="#top" className="inline-flex h-11 items-center text-sm text-muted hover:text-fg">
          Back to top
        </a>
      </div>
    </footer>
  );
}
