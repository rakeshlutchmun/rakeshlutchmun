import { useId, type ReactNode } from "react";
import type { Project } from "@/data/studio";

type FrameProps = {
  w?: number;
  h?: number;
  children: ReactNode;
};

function Frame({ w = 400, h = 520, children }: FrameProps) {
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="block h-full w-full" aria-hidden="true">
      <rect width={w} height={h} className="fill-bg" />
      {children}
    </svg>
  );
}

function CropMarks({ w, h }: { w: number; h: number }) {
  const m = 16;
  const len = 18;
  const lines = [
    [m, m, m + len, m],
    [m, m, m, m + len],
    [w - m, m, w - m - len, m],
    [w - m, m, w - m, m + len],
    [m, h - m, m + len, h - m],
    [m, h - m, m, h - m - len],
    [w - m, h - m, w - m - len, h - m],
    [w - m, h - m, w - m, h - m - len],
  ];
  return (
    <g className="stroke-muted" strokeWidth="1" fill="none">
      {lines.map((line, i) => (
        <line key={i} x1={line[0]} y1={line[1]} x2={line[2]} y2={line[3]} />
      ))}
    </g>
  );
}

export function Mark({ className = "size-9" }: { className?: string }) {
  return (
    <span
      className={`relative inline-flex items-center justify-center overflow-hidden bg-fg font-display text-sm font-extrabold tracking-tight text-bg ${className}`}
      aria-hidden="true"
    >
      <span className="absolute bottom-0 left-0 top-0 w-1 bg-cyan" />
      RL
      <span className="absolute right-0.5 top-0.5 size-1.5 bg-ember" />
    </span>
  );
}

export function Poster({ id }: { id: Project["id"] }) {
  switch (id) {
    case "aurum":
      return <Aurum />;
    case "isle":
      return <Isle />;
    case "roast":
      return <Roast />;
    case "kite":
      return <Kite />;
    case "mare":
      return <Mare />;
    case "form":
      return <FormPoster />;
    default:
      return null;
  }
}

function Aurum() {
  return (
    <Frame>
      <CropMarks w={400} h={520} />
      <circle cx="248" cy="196" r="112" className="fill-none stroke-cyan" strokeWidth="1.5" />
      <circle cx="248" cy="196" r="72" className="fill-none stroke-line" strokeWidth="1" />
      <path d="M248 84 A112 112 0 0 1 348 250" className="fill-none stroke-ember" strokeWidth="6" />
      <rect x="40" y="40" width="16" height="16" className="fill-ember" />
      <text x="40" y="430" className="poster-type fill-fg" fontSize="54">
        AURUM
      </text>
      <text x="40" y="462" className="poster-meta fill-muted" fontSize="12">
        ONE ARC · IDENTITY
      </text>
    </Frame>
  );
}

function Isle() {
  return (
    <Frame>
      <rect x="0" y="0" width="22" height="520" className="fill-cyan" />
      <line x1="70" y1="-20" x2="430" y2="470" className="stroke-ember" strokeWidth="10" />
      <text x="48" y="250" className="poster-type fill-fg" fontSize="92">
        ISLE
      </text>
      <text x="52" y="292" className="poster-meta fill-fg" fontSize="13">
        HARBOUR / NIGHT
      </text>
      <text x="52" y="470" className="poster-meta fill-cyan" fontSize="12">
        21 JUNE
      </text>
      <text x="300" y="470" className="poster-type fill-ember" fontSize="28">
        25
      </text>
    </Frame>
  );
}

function Roast() {
  const bars = Array.from({ length: 18 }, (_, i) => i);
  return (
    <Frame>
      <rect x="36" y="36" width="328" height="448" className="fill-none stroke-line" strokeWidth="1" />
      <rect x="58" y="78" width="284" height="340" className="fill-surface" />
      <rect x="78" y="108" width="36" height="36" className="fill-cyan" />
      <text x="78" y="188" className="poster-meta fill-muted" fontSize="12">
        ORIGIN
      </text>
      <text x="78" y="250" className="poster-type fill-fg" fontSize="52">
        ROAST
      </text>
      <text x="78" y="330" className="poster-type fill-ember" fontSize="64">
        21
      </text>
      <g>
        {bars.map((bar) => (
          <rect
            key={bar}
            x={78 + bar * 13}
            y="390"
            width={bar % 4 === 0 ? 8 : 4}
            height="22"
            className={bar % 5 === 0 ? "fill-cyan" : "fill-fg"}
          />
        ))}
      </g>
    </Frame>
  );
}

function Kite() {
  const heights = [46, 78, 62, 110, 88, 140, 96, 70, 120, 84];
  return (
    <Frame>
      <text x="36" y="64" className="poster-type fill-fg" fontSize="28">
        KITE
      </text>
      <text x="250" y="64" className="poster-type fill-ember" fontSize="28">
        2.4
      </text>
      <rect x="36" y="96" width="328" height="300" className="fill-surface" />
      <line x1="56" y1="360" x2="344" y2="360" className="stroke-line" strokeWidth="1" />
      {heights.map((height, i) => (
        <rect
          key={i}
          x={60 + i * 30}
          y={360 - height}
          width="16"
          height={height}
          className={i === 5 ? "fill-ember" : "fill-cyan"}
        />
      ))}
      <text x="36" y="460" className="poster-meta fill-muted" fontSize="12">
        CYAN IS DATA · EMBER IS THE FIGURE
      </text>
    </Frame>
  );
}

function Mare() {
  const courses = [
    ["01", "Oyster"],
    ["02", "Line fish"],
    ["03", "Citrus"],
    ["04", "Dark rum"],
  ];
  return (
    <Frame>
      <text x="40" y="78" className="poster-type fill-fg" fontSize="48">
        MARE
      </text>
      <text x="230" y="72" className="poster-meta fill-ember" fontSize="12">
        TABLE
      </text>
      <rect x="40" y="100" width="72" height="4" className="fill-cyan" />
      {courses.map(([n, name], i) => {
        const y = 180 + i * 68;
        return (
          <g key={n}>
            <line x1="40" y1={y - 36} x2="360" y2={y - 36} className="stroke-line" strokeWidth="1" />
            <text x="40" y={y} className="poster-meta fill-cyan" fontSize="13">
              {n}
            </text>
            <text x="100" y={y} className="poster-type fill-fg" fontSize="26">
              {name}
            </text>
          </g>
        );
      })}
    </Frame>
  );
}

function FormPoster() {
  const cells = [
    [0, 0, "fill-raised"],
    [1, 0, "fill-raised"],
    [2, 0, "fill-cyan"],
    [0, 1, "fill-raised"],
    [3, 1, "fill-fg"],
    [1, 2, "fill-raised"],
    [2, 2, "fill-ember"],
    [3, 2, "fill-raised"],
    [0, 3, "fill-fg"],
    [2, 3, "fill-raised"],
  ] as const;
  return (
    <Frame>
      <text x="36" y="58" className="poster-meta fill-muted" fontSize="12">
        ROOM GRID
      </text>
      {cells.map(([col, row, fill], i) => (
        <rect key={i} x={36 + col * 84} y={84 + row * 72} width="76" height="64" className={fill} />
      ))}
      <circle cx="318" cy="250" r="46" className="fill-none stroke-ember" strokeWidth="3" />
      <text x="36" y="450" className="poster-type fill-fg" fontSize="48">
        FORM
      </text>
      <text x="250" y="450" className="poster-type fill-cyan" fontSize="48">
        09
      </text>
    </Frame>
  );
}

export type FieldMode = "grid" | "poster" | "mark";

export function FieldGraphic({
  mode,
  columns,
  shift,
  heat,
}: {
  mode: FieldMode;
  columns: number;
  shift: number;
  heat: number;
}) {
  const rawId = useId();
  const uid = rawId.replace(/:/g, "");
  const w = 640;
  const h = 400;
  const ember = heat / 100;
  const gap = w / columns;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="block h-full w-full" role="img" aria-label="Live construction graphic">
      <rect width={w} height={h} className="fill-bg" />
      <defs>
        <pattern id={uid} width={gap} height={gap} patternUnits="userSpaceOnUse">
          <path d={`M ${gap} 0 H 0 V ${gap}`} className="stroke-line" strokeWidth="1" fill="none" />
        </pattern>
      </defs>
      {mode === "grid" ? <rect width={w} height={h} fill={`url(#${uid})`} /> : null}

      {mode === "grid"
        ? Array.from({ length: columns }, (_, i) =>
            (i + shift) % 3 === 0 ? (
              <rect key={i} x={i * gap} y="0" width={Math.max(gap - 8, 6)} height={h} className="fill-cyan" opacity="0.18" />
            ) : null,
          )
        : null}

      {mode === "poster" ? (
        <g>
          <rect x={28 + shift * 10} y="0" width={8 + columns} height={h} className="fill-cyan" />
          <line
            x1={shift * 36}
            y1="0"
            x2={w}
            y2={h - shift * 16}
            className="stroke-ember"
            strokeWidth="8"
            opacity={ember}
          />
          <text x="48" y="230" className="poster-type fill-fg" fontSize="140">
            RL
          </text>
          <text x="52" y="280" className="poster-meta fill-muted" fontSize="14">
            {`FIELD / ${String(columns).padStart(2, "0")} COL`}
          </text>
          {Array.from({ length: Math.min(columns, 12) }, (_, i) => (
            <rect
              key={i}
              x={48 + i * 28}
              y="320"
              width="16"
              height={i === shift % columns ? 48 : 22 + ((i * 7) % 18)}
              className={i === shift % columns ? "fill-ember" : "fill-fg"}
              opacity={i === shift % columns ? ember : 1}
            />
          ))}
        </g>
      ) : null}

      {mode === "mark" ? (
        <g>
          <circle
            cx={320}
            cy={190}
            r={70 + columns * 6}
            className="fill-none stroke-cyan"
            strokeWidth="2"
          />
          <rect
            x={250 + shift * 6}
            y="120"
            width="120"
            height="120"
            className="fill-none stroke-fg"
            strokeWidth="2"
            transform={`rotate(${shift * 6} 320 190)`}
          />
          <rect x="300" y="170" width="28" height="80" className="fill-fg" />
          <rect x="300" y="170" width="70" height="16" className="fill-fg" />
          <rect x="300" y="214" width="52" height="16" className="fill-fg" />
          <rect x="360" y="250" width="22" height="22" className="fill-ember" opacity={ember} />
          <text x="48" y="360" className="poster-meta fill-muted" fontSize="14">
            MARK · CONSTRUCTED
          </text>
        </g>
      ) : null}

      {mode === "grid" ? (
        <g>
          <rect x={shift * 28} y={80 + (columns % 5) * 16} width="180" height="8" className="fill-ember" opacity={ember} />
          <text x="36" y="48" className="poster-meta fill-fg" fontSize="14">
            {`GRID ${columns} · SHIFT ${shift}`}
          </text>
          <text x="36" y="360" className="poster-type fill-fg" fontSize="64">
            FIELD
          </text>
        </g>
      ) : null}
    </svg>
  );
}
