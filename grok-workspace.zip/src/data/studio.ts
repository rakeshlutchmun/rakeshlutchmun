export type Discipline = "Identity" | "Digital" | "Web" | "Print";

export type Project = {
  id: string;
  title: string;
  specimen: string;
  year: string;
  discipline: Discipline;
  summary: string;
  brief: string;
  approach: string;
  outcome: string;
  deliverables: string[];
};

export const disciplines = ["All", "Identity", "Digital", "Web", "Print"] as const;
export type Filter = (typeof disciplines)[number];

export const projects: Project[] = [
  {
    id: "aurum",
    title: "Aurum",
    specimen: "Resort identity",
    year: "2025",
    discipline: "Identity",
    summary: "A mark cut from one arc. Quiet enough for a front desk, strict enough for a sign.",
    brief: "The brief arrived as a gold script and a brochure of sunsets. The place needed to feel expensive without looking like every other island hotel.",
    approach:
      "The script went. The mark is a single arc and a cut counter. Black, bone, and a measured cyan. Stationery and the site share one grid.",
    outcome: "A system the desk, the site, and the beach sign can all use without a seasonal redesign.",
    deliverables: ["Wordmark", "Monogram", "Colour rules", "Stationery", "Signage grid"],
  },
  {
    id: "isle",
    title: "Isle",
    specimen: "Harbour festival",
    year: "2025",
    discipline: "Digital",
    summary: "One bar, one slash, type you can read from a moving car.",
    brief: "A one-night harbour festival needed a poster that still worked as a story, a ticket, and a LED wall.",
    approach:
      "Nothing illustrative. A cyan column, an ember slash, and a name set so large the crop can change and the poster still holds.",
    outcome: "One master that scales from a phone story to a hoarding without a second layout.",
    deliverables: ["Poster system", "Story crops", "Ticket", "Motion stills"],
  },
  {
    id: "roast",
    title: "Roast 21",
    specimen: "Coffee packing",
    year: "2024",
    discipline: "Print",
    summary: "The red is rationed. One word is allowed to shout.",
    brief: "A small roaster wanted packaging that looked considered on a black shelf and readable in a morning kitchen.",
    approach:
      "A bone label, a cyan stamp, and the word ROAST in ember. Everything else is quiet type: origin, grind, a short rule.",
    outcome: "A pouch, a stamp, and a café menu that obviously belong together.",
    deliverables: ["Pouch", "Stamp", "Menu", "Shelf card"],
  },
  {
    id: "kite",
    title: "Kite",
    specimen: "Finance product",
    year: "2025",
    discipline: "Web",
    summary: "Cyan is the data. Ember is the only number that matters.",
    brief: "A finance app was loud: gradients, confetti, three accents. People could not find the balance.",
    approach:
      "Black screens. One chart language. The figure you came for is ember; everything else steps back. Type is the interface.",
    outcome: "A product UI a person can read at arm’s length on a bright pavement.",
    deliverables: ["App UI", "Chart system", "Type scale", "Marketing site"],
  },
  {
    id: "mare",
    title: "Mare",
    specimen: "Dining room",
    year: "2024",
    discipline: "Print",
    summary: "A tasting menu set like a score. Rules, not decoration.",
    brief: "The room was already dark. The menu was a script font on cream card, and it fought the food.",
    approach:
      "Courses numbered, a single cyan rule, ember only on the wine. Paper large enough to feel like an object.",
    outcome: "Print that sits on the table and does not ask to be photographed to be understood.",
    deliverables: ["Menu", "Wine card", "Reservation card", "Type specimen"],
  },
  {
    id: "form",
    title: "Form 09",
    specimen: "Exhibition site",
    year: "2026",
    discipline: "Digital",
    summary: "The grid is the exhibit. The site does not decorate the work.",
    brief: "A nine-artist show needed a site that could change order every week and still look authored.",
    approach:
      "Twelve columns, a circle that marks the current room, and type that can be swapped without breaking the poster.",
    outcome: "A site the gallery updates by changing words, not by calling the studio back.",
    deliverables: ["Exhibition site", "Room grid", "Poster", "Wayfinding"],
  },
];

export const services = [
  {
    title: "Identity",
    text: "Marks, type, and colour rules a brand can keep using after the launch week.",
  },
  {
    title: "Web",
    text: "Sites and product screens drawn at phone width first, then opened up.",
  },
  {
    title: "Digital",
    text: "Posters, campaigns, and systems that crop cleanly from a story to a wall.",
  },
  {
    title: "Print",
    text: "Packaging, menus, and signage with the same grid as the screen work.",
  },
] as const;

export const steps = [
  {
    n: "01",
    title: "Listen",
    text: "The brief, the constraint, and the thing the brand refuses to say out loud.",
  },
  {
    n: "02",
    title: "System",
    text: "Type, grid, two colours. Rules are written before anything is decorated.",
  },
  {
    n: "03",
    title: "Make",
    text: "Marks, pages, and files a printer and a developer can both open.",
  },
  {
    n: "04",
    title: "Hold",
    text: "Checked on a phone, a laptop, and a print sheet. Then it is handed over.",
  },
] as const;

export const ticker = [
  "Identity",
  "Web",
  "Digital",
  "Print",
  "Type",
  "Grid",
  "Black field",
  "Mauritius",
];

export const NOTES_KEY = "rl-studio-notes";
